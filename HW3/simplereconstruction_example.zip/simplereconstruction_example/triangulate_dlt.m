
function outpoint = triangulate_dlt(pl,pr, Rlr,tlr);

%% Write for extra credit





